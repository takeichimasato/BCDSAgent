-- Taxi Company A
--#BData CompanyA CompanyA.db 44444 DRV_A VEH_x> V_AREA> CUST_X>! CUST_Y>!

-- DRV_A driverID is hidden from Dispatching Center
-- CUST_X and CUST_Y are NULL during cruising and filled by Dispatchers

-- Arrange CUST_X and CUST_Y for avoiding duplicate allocation
UPDATE CompanyA
  SET CUST_X=NULL
    WHERE
      CUST_X='InUse' AND
      CUST_Y IS NULL;
UPDATE CompanyA
  SET CUST_Y=NULL
    WHERE
      CUST_Y='InUse' AND
      CUST_X IS NULL;
UPDATE CompanyA
  SET CUST_X='InUse'
    WHERE
      CUST_X IS NULL AND
      CUST_Y IS NOT NULL;
UPDATE CompanyA
  SET CUST_Y='InUse'
    WHERE
      CUST_Y IS NULL AND
      CUST_X IS NOT NULL;

-- Cruising Area is changed at pseudo-random when BData is updated
UPDATE CompanyA SET V_AREA='BB' WHERE V_AREA='A';
UPDATE CompanyA SET V_AREA='EE' WHERE V_AREA='B';
UPDATE CompanyA SET V_AREA='FF' WHERE V_AREA='C';
UPDATE CompanyA SET V_AREA='AA' WHERE V_AREA='D';
UPDATE CompanyA SET V_AREA='HH' WHERE V_AREA='E';
UPDATE CompanyA SET V_AREA='II' WHERE V_AREA='F';
UPDATE CompanyA SET V_AREA='DD' WHERE V_AREA='G';
UPDATE CompanyA SET V_AREA='GG' WHERE V_AREA='H';
UPDATE CompanyA SET V_AREA='FF' WHERE V_AREA='I';
UPDATE CompanyA SET V_AREA='A' WHERE V_AREA='AA';
UPDATE CompanyA SET V_AREA='B' WHERE V_AREA='BB';
UPDATE CompanyA SET V_AREA='C' WHERE V_AREA='CC';
UPDATE CompanyA SET V_AREA='D' WHERE V_AREA='DD';
UPDATE CompanyA SET V_AREA='E' WHERE V_AREA='EE';
UPDATE CompanyA SET V_AREA='F' WHERE V_AREA='FF';
UPDATE CompanyA SET V_AREA='G' WHERE V_AREA='GG';
UPDATE CompanyA SET V_AREA='H' WHERE V_AREA='HH';
UPDATE CompanyA SET V_AREA='I' WHERE V_AREA='II';
