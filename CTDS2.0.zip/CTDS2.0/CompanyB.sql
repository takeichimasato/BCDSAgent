-- Taxi Company B
--#BData CompanyB CompanyB.db 44445 DRV_B VEH_x> V_AREA> CUST_X>! CUST_Y>!

-- DRV_B driverID is hidden from Dispatching Center
-- CUST_X and CUST_Y are NULL during cruising and filled by Dispatchers

-- Arrange CUST_X and CUST_Y for avoiding duplicate allocation
UPDATE CompanyB
  SET CUST_X=NULL
    WHERE
      CUST_X='InUse' AND
      CUST_Y IS NULL;
UPDATE CompanyB
  SET CUST_Y=NULL
    WHERE
      CUST_Y='InUse' AND
      CUST_X IS NULL;
UPDATE CompanyB
  SET CUST_X='InUse'
    WHERE
      CUST_X IS NULL AND
      CUST_Y IS NOT NULL;
UPDATE CompanyB
  SET CUST_Y='InUse'
    WHERE
      CUST_Y IS NULL AND
      CUST_X IS NOT NULL;
-- Cruising Area is changed at pseudo-random at every time BData is updated
UPDATE CompanyB SET V_AREA='DD' WHERE V_AREA='A';
UPDATE CompanyB SET V_AREA='EE' WHERE V_AREA='B';
UPDATE CompanyB SET V_AREA='FF' WHERE V_AREA='C';
UPDATE CompanyB SET V_AREA='AA' WHERE V_AREA='D';
UPDATE CompanyB SET V_AREA='FF' WHERE V_AREA='E';
UPDATE CompanyB SET V_AREA='II' WHERE V_AREA='F';
UPDATE CompanyB SET V_AREA='DD' WHERE V_AREA='G';
UPDATE CompanyB SET V_AREA='GG' WHERE V_AREA='H';
UPDATE CompanyB SET V_AREA='HH' WHERE V_AREA='I';
UPDATE CompanyB SET V_AREA='A' WHERE V_AREA='AA';
UPDATE CompanyB SET V_AREA='B' WHERE V_AREA='BB';
UPDATE CompanyB SET V_AREA='C' WHERE V_AREA='CC';
UPDATE CompanyB SET V_AREA='D' WHERE V_AREA='DD';
UPDATE CompanyB SET V_AREA='E' WHERE V_AREA='EE';
UPDATE CompanyB SET V_AREA='F' WHERE V_AREA='FF';
UPDATE CompanyB SET V_AREA='G' WHERE V_AREA='GG';
UPDATE CompanyB SET V_AREA='H' WHERE V_AREA='HH';
UPDATE CompanyB SET V_AREA='I' WHERE V_AREA='II';
