-- Coordinator
--#BData  Coordinator  Coordinator.db  55555  >X >Y >Z Chapter> Draft> Comment>! Revision>
--#IPort  Member_X  localhost  55556  >X
--#IPort  Member_Y  localhost  55557  >Y
--#IPort  Member_Z  localhost  55558  >Z
--
-- Coordinator arranges each Chapter drafted by members
UPDATE Coordinator
  SET Draft =
    (SELECT (MAX(X)-AVG(X)) FROM Coordinator)
  WHERE Chapter='X';
UPDATE Coordinator
  SET Draft =
    (SELECT (AVG(Y)-MIN(Y)) FROM Coordinator)
  WHERE Chapter='Y';
UPDATE Coordinator
  SET Draft =
    (SELECT (MAX(Z)-MIN(Z)) FROM Coordinator)
  WHERE Chapter='Z';
-- Coordinator judges comments to circulate revision
UPDATE Coordinator
  SET Revision =
    (SELECT Draft-Comment FROM Coordinator
	  WHERE Chapter='X')
  WHERE Chapter='X' AND Comment IS NOT NULL;
UPDATE Coordinator
  SET Revision =
    (SELECT Draft-Comment FROM Coordinator
	  WHERE Chapter='Y')
  WHERE Chapter='Y' AND Comment IS NOT NULL;
UPDATE Coordinator
  SET Revision =
    (SELECT Draft-Comment FROM Coordinator
	  WHERE Chapter='Z')
  WHERE Chapter='Z' AND Comment IS NOT NULL;
