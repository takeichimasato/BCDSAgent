-- Dispatching Center
----$$ To make Interactive Application, delete '--' at the beginning.
--#BData Dispatcher Dispatcher.db 55555 >VEH_A >!CUST_A >VEH_B >!CUST_B >V_AREA >CUST >C_AREA >!VEH
--#IPort CompanyA localhost 55556 >VEH_A >!CUST_A >V_AREA
--#IPort CompanyB localhost 55557 >VEH_B >!CUST_B >V_AREA
--#IPort Customer localhost 55558 >CUST >!VEH >C_AREA
/*
-- Dispatcher matches C_AREA with V_AREA and assign VEH_? to VEH
--
--
-- Make vehicle free if not exist in CUST
UPDATE Dispatcher
    SET CUST_A=NULL
	  WHERE
      CUST_A IS NOT NULL AND
      CUST_A NOT IN
	      (SELECT CUST FROM Dispatcher WHERE CUST IS NOT NULL);
UPDATE Dispatcher
    SET CUST_B=NULL
	  WHERE
	    CUST_B IS NOT NULL AND
      CUST_B NOT IN
        (SELECT CUST FROM Dispatcher WHERE CUST IS NOT NULL);

-- Create a view of undispatched requests
CREATE VIEW Undispatched (VEH_A,VEH_B,V_AREA,CUST,VEH) AS
  SELECT Company.VEH_A,Company.VEH_B,Company.V_AREA,Customer.CUST,Customer.VEH
    FROM Dispatcher Company
      INNER JOIN Dispatcher Customer
        ON Company.V_AREA=Customer.C_AREA
          WHERE -- only available vehicles
            (Company.CUST_A IS NULL) AND
            (Company.CUST_B IS NULL) AND
            (Customer.VEH IS NULL)
          GROUP BY Customer.C_AREA;

-- Update CUST_A or CUST_B with CUST
UPDATE Dispatcher
    SET CUST_A=(
    -- beware NULL returned when conditions fail
	    SELECT CUST FROM Undispatched
		    WHERE
		      Dispatcher.VEH_A IS NOT NULL AND
		      Dispatcher.VEH_A=Undispatched.VEH_A)
    WHERE CUST_A IS NULL;
UPDATE Dispatcher
    SET CUST_B=(
    -- beware NULL returned when conditions fail
	    SELECT CUST FROM Undispatched
		    WHERE
		      Dispatcher.VEH_B IS NOT NULL AND
		      Dispatcher.VEH_B=Undispatched.VEH_B)
    WHERE CUST_B IS NULL;

-- Update VEH with VEH_A or VEH_B dispatched
UPDATE Dispatcher
    SET VEH=(
	    SELECT VEH_A FROM Dispatcher AS X
	      WHERE
		      Dispatcher.CUST=X.CUST_A)
	  WHERE
      CUST IS NOT NULL AND VEH IS NULL;
UPDATE Dispatcher
    SET VEH=(
	    SELECT VEH_B FROM Dispatcher AS X
	      WHERE
		      Dispatcher.CUST=X.CUST_B)
	  WHERE
      CUST IS NOT NULL AND VEH IS NULL;

-- drop View
DROP VIEW Undispatched
*/

import BCDSLib

dispatcher :: (V Int) -> (V Int)
dispatcher (xCols,xV) =
-- xCols = [">VEH_A",">!CUST_A",">VEH_B",">!CUST_B","V_AREA",
--          ">CUST",">C_AREA",">!VEH"]
  -- Make vehicle free if not exist in CUST
  let
    -- customers to whom vehicle are allocated
    customers = filter (\cust->cust/=Nothing)
                  (map (\(k,row)->row!!5) (toList xV))
    xV1 = HM.map mkfreeVEH_A xV
    xV2 = HM.map mkfreeVEH_B xV1
    mkfreeVEH_A = mkfreeVEH 1 -- CUST_A
    mkfreeVEH_A = mkfreeVEH 3 -- CUST_B
    mkfreeVEH j row =
      case (row!!j) of
        Nothing -> row
        cust@(Just _) ->
          if elem cust customers then row
          else take j row ++[Nothing]++drop (j+1) row
    xV3 = HM.map allocVEH xV2
    unallocated = -- not yet dispatched
      filter (\(cust,c_area,veh)->(cust/=Nothing)&&(veh==Nothing))
        (map (\(k,row)->(row!!5,row!!6,row!!7) (toList xV))
    allocVEH row =
      case (row!!5) of
        Nothing -> row -- record not for Customer Service
        cust@(Just c) ->
          case (row!!7) of
            (Just _) -> row -- already allocated
            Nothing -> -- try to allocate VEH
              let
                availVEH =
                  filter (\r->((r!!4==row!!6)&&((r!!1/=Nothing) -- V_AREA==C_AREA
                    (map (\(k,r)->take 5 r) (toList xV))
