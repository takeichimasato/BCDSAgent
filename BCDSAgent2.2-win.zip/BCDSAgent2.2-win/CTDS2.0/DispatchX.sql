-- Dispatching Center X
--#BData DispatchX DispatchX.db 55555 >VEH_x >!CUST_X >V_AREA >CUST >C_AREA >!VEH
--#IPort CompanyA localhost 44444 >VEH_x >!CUST_X >V_AREA
--#IPort CompanyB localhost 44445 >VEH_x >!CUST_X >V_AREA
--#IPort CustomerX localhost 33333 >CUST >!VEH >C_AREA
-- DispatchX matches C_AREA with V_AREA and assign VEH_x to VEH
--
-- Make temporarily assigned vehicle to VEH
UPDATE DispatchX
    SET VEH=(
	    SELECT VEH_x FROM DispatchX AS X
	      WHERE
		      DispatchX.CUST=X.CUST_X)
	  WHERE
      CUST IS NOT NULL AND VEH IS NULL;

-- Make vehicle free if not exist in CUST
UPDATE DispatchX
    SET CUST_X=NULL
	  WHERE
      CUST_X IS NOT NULL AND
      CUST_X != 'InUse' AND
      CUST_X NOT IN
	      (SELECT CUST FROM DispatchX WHERE CUST IS NOT NULL);

-- Create a view of undispatched requests
CREATE VIEW Undispatched (VEH_x,V_AREA,CUST,VEH) AS
  SELECT Company.VEH_x,Company.V_AREA,Customer.CUST,Customer.VEH
    FROM DispatchX Company
      INNER JOIN DispatchX Customer
        ON Company.V_AREA=Customer.C_AREA
          WHERE -- only available vehicles
            (Company.CUST_X IS NULL) AND
            (Customer.VEH IS NULL)
          GROUP BY Customer.C_AREA;

-- Update CUST_X with CUST
UPDATE DispatchX
    SET CUST_X=(
    -- beware NULL returned when conditions fail
	    SELECT CUST FROM Undispatched
		    WHERE
		      DispatchX.VEH_x IS NOT NULL AND
		      DispatchX.VEH_x=Undispatched.VEH_x)
    WHERE CUST_X IS NULL;

-- drop View
DROP VIEW Undispatched
