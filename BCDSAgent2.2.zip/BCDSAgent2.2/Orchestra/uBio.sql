-- uBio
----$$ To make Interactive Application, delete '--' at the beginning.
--#BData uBio CDSS.db 55557 >G_n >G_c U_n>! U_c>!
--#IPort GUS localhost 55556 >G_n >G_c
INSERT INTO uBio (U_n,U_c)
  SELECT G_n,G_c FROM uBio AS G
    WHERE
      (G_n IS NOT NULL AND G_c IS NOT NULL)
      AND NOT EXISTS
        (SELECT U_n,U_c FROM uBio
          WHERE
          (U_n IS NOT NULL AND U_c IS NOT NULL)
          AND G.G_n=U_n AND G.G_c=U_c);
