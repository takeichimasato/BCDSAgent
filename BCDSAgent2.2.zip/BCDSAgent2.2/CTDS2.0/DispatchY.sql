-- Dispatching Center Y
--#BData DispatchY DispatchY.db 55556 >VEH_x >!CUST_Y >V_AREA >CUST >C_AREA >!VEH
--#IPort CompanyA localhost 44444 >VEH_x >!CUST_Y >V_AREA
--#IPort CompanyB localhost 44445 >VEH_x >!CUST_Y >V_AREA
--#IPort CustomerY localhost 33334 >CUST >!VEH >C_AREA
-- DispatchY matches C_AREA with V_AREA and assign VEH_x to VEH
--
-- Make temporarily assigned vehicle to VEH
UPDATE DispatchY
    SET VEH=(
	    SELECT VEH_x FROM DispatchY AS X
	      WHERE
		      DispatchY.CUST=X.CUST_Y)
	  WHERE
      CUST IS NOT NULL AND VEH IS NULL;

-- Make vehicle free if not exist in CUST
UPDATE DispatchY
    SET CUST_Y=NULL
	  WHERE
      CUST_Y IS NOT NULL AND
      CUST_Y != 'InUse' AND
      CUST_Y NOT IN
	      (SELECT CUST FROM DispatchY WHERE CUST IS NOT NULL);

-- Create a view of undispatched requests
CREATE VIEW Undispatched (VEH_x,V_AREA,CUST,VEH) AS
  SELECT Company.VEH_x,Company.V_AREA,Customer.CUST,Customer.VEH
    FROM DispatchY Company
      INNER JOIN DispatchY Customer
        ON Company.V_AREA=Customer.C_AREA
          WHERE -- only available vehicles
            (Company.CUST_Y IS NULL) AND
            (Customer.VEH IS NULL)
          GROUP BY Customer.C_AREA;

-- Update CUST_Y with CUST
UPDATE DispatchY
    SET CUST_Y=(
    -- beware NULL returned when conditions fail
	    SELECT CUST FROM Undispatched
		    WHERE
		      DispatchY.VEH_x IS NOT NULL AND
		      DispatchY.VEH_x=Undispatched.VEH_x)
    WHERE CUST_Y IS NULL;

-- drop View
DROP VIEW Undispatched
