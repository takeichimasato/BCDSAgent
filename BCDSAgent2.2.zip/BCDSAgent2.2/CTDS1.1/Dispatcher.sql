-- Dispatching Center
----$$ To make Interactive Application, delete '--' at the beginning.
--#BData Dispatcher Dispatcher.db 55555 >VEH_x >!CUST_x >V_AREA >CUST >C_AREA >!VEH
--#IPort CompanyA localhost 55556 >VEH_x >!CUST_x >V_AREA
--#IPort CompanyB localhost 55557 >VEH_x >!CUST_x >V_AREA
--#IPort Customer localhost 55558 >CUST >!VEH >C_AREA
-- Dispatcher matches C_AREA with V_AREA and assign VEH_x to VEH
--
--
-- Make vehicle free if not exist in CUST
UPDATE Dispatcher
    SET CUST_x=NULL
	  WHERE
      CUST_x IS NOT NULL AND
      CUST_x NOT IN
	      (SELECT CUST FROM Dispatcher WHERE CUST IS NOT NULL);

-- Create a view of undispatched requests
CREATE VIEW Undispatched (VEH_x,V_AREA,CUST,VEH) AS
  SELECT Company.VEH_x,Company.V_AREA,Customer.CUST,Customer.VEH
    FROM Dispatcher Company
      INNER JOIN Dispatcher Customer
        ON Company.V_AREA=Customer.C_AREA
          WHERE -- only available vehicles
            (Company.CUST_x IS NULL) AND
            (Customer.VEH IS NULL)
          GROUP BY Customer.C_AREA;

-- Update CUST_x with CUST
UPDATE Dispatcher
    SET CUST_x=(
    -- beware NULL returned when conditions fail
	    SELECT CUST FROM Undispatched
		    WHERE
		      Dispatcher.VEH_x IS NOT NULL AND
		      Dispatcher.VEH_x=Undispatched.VEH_x)
    WHERE CUST_x IS NULL;

-- Update VEH with VEH_x dispatched
UPDATE Dispatcher
    SET VEH=(
	    SELECT VEH_x FROM Dispatcher AS X
	      WHERE
		      Dispatcher.CUST=X.CUST_x)
	  WHERE
      CUST IS NOT NULL AND VEH IS NULL;

-- drop View
DROP VIEW Undispatched
